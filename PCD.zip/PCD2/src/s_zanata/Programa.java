package s_zanata;

public class Programa {
	
	public static void main(String[] args) {
		
		new Producer();
		new Consumer();
		
	}
}
